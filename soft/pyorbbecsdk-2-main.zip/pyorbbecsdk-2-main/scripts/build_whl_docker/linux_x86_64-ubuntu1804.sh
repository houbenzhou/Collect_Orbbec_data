docker run --rm -v $(pwd):/workspace pyorbbecsdk-env.x86_64
