# Build docker image
docker build -t pyorbbecsdk-env.linux_x86_64-multipython -f ./docker/build_env/linux_x86_64-multipython.dockerfile .